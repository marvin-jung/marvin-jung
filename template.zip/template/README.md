# Portfolio Template
Template for personal webpage. Use Reactjs, standart HTML and Material UI - deployed used github pages. 


Credits: 
This material was used in a Hands-on Guided Project available on Coursera. 
The free template was made by [Styleshout](https://www.styleshout.com/free-templates/ceevee/)
Some modifications are also made by [tbakerx](https://github.com/tbakerx/react-resume-template). 
Feel free to modify to way you like, but remember to keep these credits on your repository. 